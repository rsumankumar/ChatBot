
# coding: utf-8

# In[1]:


import pandas as pd
import datetime as DT
import dateutil.relativedelta as REL


# In[6]:


def getWeekDay(wDay):
    if(wDay == 'monday' or wDay == 'mon'):
        return REL.MO
    elif(wDay == 'tuesday' or wDay == 'tue'):
        return REL.TU
    elif(wDay == 'wednesday' or wDay == 'wed'):
        return REL.WE
    elif(wDay == 'thursday' or wDay == 'thu'):
        return REL.TH
    elif(wDay == 'friday' or wDay == 'fri'):
        return REL.FR
    elif(wDay == 'saturday' or wDay == 'sat'):
        return REL.SA
    elif(wDay == 'sunday' or wDay == 'sun'):
        return REL.SU

def getNextDay(wDay):
    wDay = wDay.lower()
    if(wDay == 'today'):
        return DT.date.today().strftime ("%d-%m-%Y")
    
    if("next" in wDay):
        w = wDay.split()[1]
    else:
        w = wDay
    print('w :: ',w)
    today = DT.date.today()
    rd = REL.relativedelta(days=1, weekday=getWeekDay(w.lower()))
    next_givenday = today + rd
    print(next_givenday)
    return next_givenday

def getMoviesList(payLoad):
    movieList = []
    if payLoad:
        if(payLoad["Language"]):
            dfl = dt[dt['Language'].str.contains(payLoad["Language"].lower())]
            movieList1 = list(set(dfl["Movie"])) or []
        if(payLoad["Actor"]):
            dfa = dt[dt['Actor'].str.contains(payLoad["Actor"].lower())]
            movieList2 = list(set(dfa["Movie"])) or []
        if(payLoad["Genre"]):
            dfg = dt[dt['Genre'].str.contains(payLoad["Genre"].lower())]
            movieList3 = list(set(dfg["Movie"])) or []
            
        temp = set(movieList1).intersection(movieList2)
        t = set(temp).intersection(movieList3)
        if(len(t)):
            movieList = t
        elif(len(temp)):
            movieList = temp
        else:
            movieList = movieList1
            
    return list(movieList)

def getMovieHall(movie):
    dfh = dt[dt['Movie'].str.contains(movie)]
    return list(set(dfh["Movie Hall"]))


# In[7]:


dt = pd.read_csv('movie_dataset.csv')
dt["fromdate"] = DT.date.today().strftime ("%d-%m-%Y")
dt["todate"] = getNextDay('Sunday').strftime ("%d-%m-%Y")
#dt


# In[8]:


dt["Language"] = dt["Language"].map(lambda x: x if type(x)!=str else x.lower())
dt["Actor"] = dt["Actor"].map(lambda x: x if type(x)!=str else x.lower())
dt["Genre"] = dt["Genre"].map(lambda x: x if type(x)!=str else x.lower())


# In[9]:


obj = {'Language': 'Hindi', 'Actor': 'Ranbir', 'Genre': 'Drama', 'Day': 'Today'}
lst = getMoviesList(obj)
day = getNextDay(obj["Day"])
halls = getMovieHall(lst[0])
print(lst) 
print(halls)


# In[335]:


dt

